# SauceDemo Manual Testing Project

Details about the project structure, modules covered, and tools used.